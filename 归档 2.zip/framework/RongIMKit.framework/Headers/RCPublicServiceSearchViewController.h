//
//  RCPublicServiceSearchViewController.h
//  RongIMKit
//
//  Created by litao on 15/4/21.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  查找公众服务账号
 */
@interface RCPublicServiceSearchViewController : UITableViewController

@end
